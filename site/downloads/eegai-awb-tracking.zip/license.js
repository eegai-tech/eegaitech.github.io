/* Licence client: e-mail OTP sign-in (shadowfax.in only), trial / premium status, UTR submit. */
const Licence = (() => {
  const CFG = EEGAI_CONFIG;
  const STORE = 'eegai_awb_licence';

  async function server(action, payload) {
    const res = await fetch(CFG.SERVER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(Object.assign({ action, product: 'awb' }, payload || {})),
      redirect: 'follow'
    });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch (e) { throw new Error('Licence server did not answer correctly. Check SERVER_URL in config.js.'); }
    if (!data.ok) throw new Error(data.error || 'Licence server error');
    return data;
  }

  async function getCached() {
    return (await chrome.storage.local.get(STORE))[STORE] || null;
  }
  async function setCached(v) {
    await chrome.storage.local.set({ [STORE]: v });
  }

  function cleanEmail(e) {
    const email = String(e || '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+$/.test(email)) throw new Error('Enter a valid e-mail address.');
    if (!email.endsWith('@' + CFG.ALLOWED_DOMAIN)) throw new Error('Only @' + CFG.ALLOWED_DOMAIN + ' e-mail addresses can register.');
    return email;
  }

  /* Step 1: e-mail a 6-digit code */
  async function sendOtp(emailRaw) {
    const email = cleanEmail(emailRaw);
    await server('sendOtp', { email, deviceId: await eegaiDeviceId() });
    return email;
  }

  /* Step 2: check the code and start the session */
  async function verifyOtp(emailRaw, otp) {
    const email = cleanEmail(emailRaw);
    if (!/^\d{6}$/.test(String(otp).trim())) throw new Error('The code is 6 digits.');
    const deviceId = await eegaiDeviceId();
    const data = await server('verifyOtp', { email, otp: String(otp).trim(), deviceId });
    const lic = { email: data.email, name: data.name || '', sessionKey: data.sessionKey, deviceId, status: data.status, checkedAt: Date.now() };
    await setCached(lic);
    return lic;
  }

  /* Refresh from server; falls back to the cached copy when offline. */
  async function refresh() {
    const lic = await getCached();
    if (!lic) return null;
    try {
      const data = await server('status', { email: lic.email, sessionKey: lic.sessionKey, deviceId: lic.deviceId });
      lic.status = data.status; lic.checkedAt = Date.now(); lic.offline = false;
      await setCached(lic);
    } catch (e) {
      if (/session/i.test(e.message)) { await signOut(); return null; }
      lic.offline = true;
    }
    return lic;
  }

  /* ms left until a server timestamp, using the server clock captured at check time */
  function timeLeft(lic, until) {
    return until - (lic.status.now + (Date.now() - lic.checkedAt));
  }

  /* Can the user track right now? */
  function allowed(lic) {
    if (!lic || !lic.status) return false;
    const s = lic.status;
    if (s.state === 'premium') return true;                        // old lifetime buyers
    if (s.state === 'active') return timeLeft(lic, s.paidUntil) > 0;  // monthly subscription
    if (s.state === 'trial') {
      // use server clock offset captured at check time
      const left = s.trialEndsAt - (s.now + (Date.now() - lic.checkedAt));
      return left > 0;
    }
    return false;
  }

  async function submitUtr(utr, upiId) {
    const lic = await getCached();
    const data = await server('submitUtr', { email: lic.email, sessionKey: lic.sessionKey, deviceId: lic.deviceId, utr, upiId });
    lic.status = data.status; lic.checkedAt = Date.now();
    await setCached(lic);
    return lic;
  }

  async function signOut() {
    await chrome.storage.local.remove(STORE);
  }

  return { timeLeft, sendOtp, verifyOtp, refresh, allowed, submitUtr, signOut, getCached };
})();
