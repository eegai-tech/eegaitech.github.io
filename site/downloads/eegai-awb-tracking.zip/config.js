/* Eegai AWB Tracking – settings. Fill SERVER_URL before loading / publishing. */
const EEGAI_CONFIG = {
  PRODUCT: 'Eegai AWB Tracking',

  // Apps Script licence server for THIS extension (Deploy > Web app > URL ending in /exec)
  SERVER_URL: 'https://script.google.com/macros/s/AKfycbzf5nCPDaiNUNaNznt12i9iNd1GAmzzdFBOiBFiCWfNO4FvUZBTs_56Mqg8KnuvYA7g/exec',


  ALLOWED_DOMAIN: 'shadowfax.in',   // only @shadowfax.in accounts can register
  PRICE_INR: 50,                    // per computer, per 30 days
  PLAN_DAYS: 30,
  TRIAL_DAYS: 2,                    // display only – the real value lives in Code.gs

  SUPPORT_PHONE: '9500400427',      // WhatsApp / call for payment help

  UPI_OPTIONS: [
    {
      label: 'UPI ID 1',
      upiId: '9500400427@superyes',
      payee: 'Sunthara Mahalingam Govindan',
      link: 'upi://pay?mode=01&ver=01&pa=9500400427%40superyes&pn=SUNTHARA+MAHALINGAM+GOVINDAN+&txntype=pay&qrmedium=02'
    },
    {
      label: 'UPI ID 2',
      upiId: 'gsmlingamagri92-4@okhdfcbank',
      payee: 'Gsm Lingam Agri',
      link: 'upi://pay?pa=gsmlingamagri92-4@okhdfcbank&pn=Gsm%20Lingam%20Agri&aid=uGICAgIDd-qXPTQ'
    }
  ],

  // Shadowfax DC portal APIs (same as the Python script)
  API: {
    LOGIN:   'https://saruman.shadowfax.in/auth/sign_in/',
    DETAILS: 'https://saruman.shadowfax.in/manifests/awbs/details/',
    FWD:     'https://saruman.shadowfax.in/ecommerce/track/v2/',
    REV:     'https://saruman.shadowfax.in/pickup/track/'
  },
  THREADS: 15,
  MAX_RETRIES: 3
};

function eegaiUpiLink(opt, orderId) {
  return opt.link + '&am=' + EEGAI_CONFIG.PRICE_INR.toFixed(2) + '&cu=INR&tn=' +
    encodeURIComponent('Eegai AWB ' + (orderId || ''));
}
