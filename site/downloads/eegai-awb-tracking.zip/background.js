/* Eegai AWB Tracking – background service worker
   Clicking the toolbar icon opens the tracker in a full browser tab
   (re-uses the tab if it is already open). */

const APP_URL = chrome.runtime.getURL('app.html');

async function openApp() {
  const tabs = await chrome.tabs.query({ url: APP_URL + '*' });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: APP_URL });
  }
}

chrome.action.onClicked.addListener(openApp);

chrome.runtime.onInstalled.addListener((d) => {
  if (d.reason === 'install') openApp();
});
