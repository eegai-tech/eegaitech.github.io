/* Eegai AWB Tracking – page logic */
(() => {
  const CFG = EEGAI_CONFIG;
  const $ = (id) => document.getElementById(id);
  let LIC = null;
  let AWBS = { fwd: [], rev: [] };
  let STOP = false;
  let LAST_REPORT = null;
  let chipTimer = null;

  function show(screen) {
    ['screen-loading', 'screen-signin', 'screen-app'].forEach(s => $(s).hidden = s !== screen);
  }

  /* ======================= LICENCE ======================= */
  async function boot() {
    show('screen-loading');
    LIC = await Licence.refresh();
    if (!LIC) { show('screen-signin'); return; }
    renderApp();
  }

  function msLeft() {
    const s = LIC.status;
    return s.trialEndsAt - (s.now + (Date.now() - LIC.checkedAt));
  }

  function renderChip() {
    const chip = $('plan-chip');
    const s = LIC.status || {};
    chip.className = 'chip';
    $('btn-renew').hidden = true;
    if (s.state === 'premium') { chip.textContent = 'Premium – lifetime'; chip.classList.add('premium'); }
    else if (s.state === 'active' && Licence.timeLeft(LIC, s.paidUntil) > 0) {
      const left = Licence.timeLeft(LIC, s.paidUntil), days = Math.ceil(left / 864e5);
      const end = new Date(Date.now() + left).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
      chip.textContent = 'Subscribed till ' + end + ' (' + days + (days === 1 ? ' day' : ' days') + ' left)';
      chip.classList.add(days <= 3 ? 'trial' : 'premium');
      $('btn-renew').hidden = false;
    }
    else if (s.state === 'trial' && msLeft() > 0) {
      const m = Math.floor(msLeft() / 60000), d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), mm = m % 60;
      chip.textContent = 'Free trial: ' + (d ? d + ' d ' + h + ' h' : h ? h + ' h ' + mm + ' min' : mm + ' min') + ' left';
      chip.classList.add('trial');
    } else if (s.state === 'other_device') { chip.textContent = 'Premium on another computer'; chip.classList.add('expired'); }
    else if (s.state === 'lapsed') { chip.textContent = 'Subscription ended'; chip.classList.add('expired'); }
    else { chip.textContent = 'Trial ended'; chip.classList.add('expired'); }
  }

  function renderApp() {
    show('screen-app');
    $('acct-email').textContent = LIC.email + (LIC.offline ? ' (offline)' : '');
    renderChip();
    clearInterval(chipTimer);
    chipTimer = setInterval(() => {
      renderChip();
      if (!Licence.allowed(LIC) && !$('tracker').hidden && !RUNNING) lockToSubscribe();
    }, 30000);
    if (Licence.allowed(LIC)) { $('tracker').hidden = false; $('subscribe').hidden = true; }
    else lockToSubscribe();
  }

  function lockToSubscribe() {
    $('tracker').hidden = true;
    $('subscribe').hidden = false;
    const s = LIC.status || {};
    $('order-id').textContent = s.orderId || '-';
    $('dev-id').textContent = (LIC.deviceId || '').slice(0, 9);
    const can = Licence.allowed(LIC);
    $('btn-back').hidden = !can;
    $('sub-title').textContent = can ? 'Renew your subscription'
      : s.state === 'lapsed' ? 'Your subscription has ended' : 'Your free trial has ended';
    $('sub-lead').innerHTML = can
      ? 'Pay <strong>₹' + CFG.PRICE_INR + '</strong> to add <strong>' + CFG.PLAN_DAYS + ' days</strong> to this computer. They add on to the days you have left.'
      : 'Pay <strong>₹' + CFG.PRICE_INR + ' for ' + CFG.PLAN_DAYS + ' days</strong> of tracking on this computer.';
    const row = $('qr-row'); row.innerHTML = '';
    const sel = $('utr-upi'); sel.innerHTML = '';
    CFG.UPI_OPTIONS.forEach(opt => {
      const qr = qrcode(0, 'M');
      qr.addData(eegaiUpiLink(opt, s.orderId));
      qr.make();
      const card = document.createElement('div');
      card.className = 'qr-card';
      card.innerHTML = '<img alt="UPI QR code for ' + opt.upiId + '" src="' + qr.createDataURL(6, 2) + '"><b>' + opt.label +
        ' – ₹' + CFG.PRICE_INR + '</b><span>' + opt.upiId + '</span>';
      row.appendChild(card);
      const o = document.createElement('option'); o.value = opt.upiId; o.textContent = opt.upiId; sel.appendChild(o);
    });
    const p = s.payment || {};
    const msg = $('pay-msg'); msg.className = 'pay-msg';
    if (s.state === 'other_device') {
      $('subscribe').querySelector('h2').textContent = 'Your licence is on another computer';
      msg.textContent = 'Your premium licence is linked to a different computer. Message us on WhatsApp to move it here.';
    } else if (p.state === 'pending') {
      msg.textContent = 'Payment with UTR ' + String(p.utr).replace(/^'/, '') + ' is being checked. This usually takes under 30 minutes.';
    } else if (p.state === 'rejected') {
      msg.className = 'pay-msg bad';
      msg.textContent = 'UTR ' + p.utr + ' could not be matched to a ₹' + CFG.PRICE_INR + ' payment. Check the number or message us on WhatsApp.';
    } else msg.textContent = '';
    updateWhatsApp();
    $('btn-call').href = 'tel:+91' + CFG.SUPPORT_PHONE;
    $('btn-call').textContent = 'Call ' + CFG.SUPPORT_PHONE;
  }

  function updateWhatsApp() {
    const s = (LIC && LIC.status) || {};
    const text = 'Hi, I paid for Eegai AWB Tracking (30-day subscription).\n' +
      'Email: ' + (LIC ? LIC.email : '') + '\n' +
      'Order number: ' + (s.orderId || '') + '\n' +
      'Computer ID: ' + ((LIC && LIC.deviceId) || '').slice(0, 9) + '\n' +
      'Paid to UPI: ' + $('utr-upi').value + '\n' +
      'Amount: Rs.' + CFG.PRICE_INR + '\n' +
      'UTR: ' + ($('utr').value.trim() || (s.payment && s.payment.utr) || '');
    $('btn-whatsapp').href = 'https://wa.me/91' + CFG.SUPPORT_PHONE + '?text=' + encodeURIComponent(text);
  }

  let OTP_EMAIL = '';
  let resendTimer = null;
  function signinError(t) { const e = $('signin-error'); e.textContent = t || ''; e.hidden = !t; }
  function startResendCountdown() {
    let n = 60; const b = $('btn-resend'); b.disabled = true;
    clearInterval(resendTimer);
    resendTimer = setInterval(() => {
      n--; b.textContent = n > 0 ? 'Resend code in ' + n + ' s' : 'Resend code';
      if (n <= 0) { clearInterval(resendTimer); b.disabled = false; }
    }, 1000);
  }
  async function sendCode() {
    signinError('');
    $('btn-send').disabled = true; $('btn-send').textContent = 'Sending…';
    try {
      OTP_EMAIL = await Licence.sendOtp($('si-email').value);
      $('si-sent-to').textContent = OTP_EMAIL;
      $('step-email').hidden = true; $('step-otp').hidden = false;
      $('si-otp').value = ''; $('si-otp').focus();
      startResendCountdown();
    } catch (e) { signinError(e.message); }
    finally { $('btn-send').disabled = false; $('btn-send').textContent = 'Send login code'; }
  }
  $('btn-send').onclick = sendCode;
  $('si-email').addEventListener('keydown', e => { if (e.key === 'Enter') sendCode(); });
  $('btn-resend').onclick = async () => {
    signinError('');
    try { await Licence.sendOtp(OTP_EMAIL); startResendCountdown(); }
    catch (e) { signinError(e.message); }
  };
  $('btn-change').onclick = () => { signinError(''); $('step-otp').hidden = true; $('step-email').hidden = false; $('si-email').focus(); };
  async function verifyCode() {
    signinError('');
    $('btn-verify').disabled = true;
    try { LIC = await Licence.verifyOtp(OTP_EMAIL, $('si-otp').value); renderApp(); loadLogins(); }
    catch (e) { signinError(e.message); }
    finally { $('btn-verify').disabled = false; }
  }
  $('btn-verify').onclick = verifyCode;
  $('si-otp').addEventListener('input', () => {
    $('si-otp').value = $('si-otp').value.replace(/\D/g, '').slice(0, 6);
    if ($('si-otp').value.length === 6) verifyCode();
  });

  $('btn-signout').onclick = async () => { await Licence.signOut(); LIC = null; $('step-otp').hidden = true; $('step-email').hidden = false; show('screen-signin'); };

  $('utr').addEventListener('input', () => { $('utr').value = $('utr').value.replace(/\D/g, ''); updateWhatsApp(); });
  $('utr-upi').addEventListener('change', updateWhatsApp);

  $('btn-utr').onclick = async () => {
    const utr = $('utr').value.trim();
    const msg = $('pay-msg');
    if (!/^\d{12}$/.test(utr)) { msg.className = 'pay-msg bad'; msg.textContent = 'The UTR must be exactly 12 digits.'; return; }
    $('btn-utr').disabled = true;
    msg.className = 'pay-msg'; msg.textContent = 'Submitting…';
    try {
      const before = (LIC.status && LIC.status.paidUntil) || 0;
      LIC = await Licence.submitUtr(utr, $('utr-upi').value);
      if (Licence.allowed(LIC) && (LIC.status.paidUntil || 0) > before) { $('utr').value = ''; renderApp(); return; }
      lockToSubscribe();
    } catch (e) { msg.className = 'pay-msg bad'; msg.textContent = e.message; }
    finally { $('btn-utr').disabled = false; }
  };

  $('btn-renew').onclick = () => lockToSubscribe();
  $('btn-back').onclick = () => { $('subscribe').hidden = true; $('tracker').hidden = false; };

  $('btn-recheck').onclick = async () => {
    $('pay-msg').className = 'pay-msg'; $('pay-msg').textContent = 'Checking…';
    LIC = await Licence.refresh();
    if (!LIC) { show('screen-signin'); return; }
    if (Licence.allowed(LIC)) renderApp(); else lockToSubscribe();
  };

  /* ======================= DC LOGINS ======================= */
  function readLoginForm() {
    return {
      fwd: { user: $('fwd-user').value.trim(), pass: $('fwd-pass').value, token: $('fwd-token').value.trim() },
      rev: { user: $('rev-user').value.trim(), pass: $('rev-pass').value, token: $('rev-token').value.trim() }
    };
  }

  async function loadLogins() {
    const c = await CredStore.load();
    if (!c) return;
    ['fwd', 'rev'].forEach(k => {
      $(k + '-user').value = (c[k] && c[k].user) || '';
      $(k + '-pass').value = (c[k] && c[k].pass) || '';
      $(k + '-token').value = (c[k] && c[k].token) || '';
    });
    flash('Saved logins loaded.');
  }

  function flash(t, bad) {
    const m = $('save-msg'); m.textContent = t; m.style.color = bad ? 'var(--danger)' : '';
    clearTimeout(flash.t); flash.t = setTimeout(() => m.textContent = '', 5000);
  }

  $('btn-save').onclick = async () => {
    const f = readLoginForm();
    if (!f.fwd.user && !f.rev.user && !f.fwd.token && !f.rev.token) { flash('Enter at least one login before saving.', true); return; }
    try { await CredStore.save(f); flash('Logins saved on this browser.'); }
    catch (e) { flash(e.message, true); }
  };

  $('btn-clear').onclick = async () => {
    if (!confirm('Delete the saved forward and reverse logins from this browser?')) return;
    await CredStore.clear();
    ['fwd', 'rev'].forEach(k => ['user', 'pass', 'token'].forEach(f => $(k + '-' + f).value = ''));
    flash('Saved logins deleted.');
  };

  document.querySelectorAll('.pw-toggle').forEach(b => b.onclick = () => {
    const i = $(b.dataset.for);
    i.type = i.type === 'password' ? 'text' : 'password';
    b.textContent = i.type === 'password' ? 'Show' : 'Hide';
  });

  function setBlockStatus(k, text, ok) {
    const el = $(k + '-status'); el.textContent = text; el.className = 'block-status ' + (ok ? 'ok' : 'bad');
  }

  async function getToken(k, forceLogin) {
    const f = readLoginForm()[k];
    if (f.token && !forceLogin) return f.token;
    if (!f.user || !f.pass) throw new Error('Enter the ' + (k === 'fwd' ? 'forward' : 'reverse') + ' user name and password.');
    return Tracker.login(f.user, f.pass);
  }

  $('btn-test').onclick = async () => {
    $('btn-test').disabled = true;
    for (const k of ['fwd', 'rev']) {
      const f = readLoginForm()[k];
      if (!f.user && !f.token) { setBlockStatus(k, 'Not filled in.', false); continue; }
      setBlockStatus(k, 'Checking…', true);
      try { await getToken(k, !!f.user); setBlockStatus(k, 'Login works.', true); }
      catch (e) { setBlockStatus(k, e.message, false); }
    }
    $('btn-test').disabled = false;
  };

  /* ======================= FILE INPUT ======================= */
  const drop = $('drop');
  $('file').addEventListener('change', e => e.target.files[0] && readFile(e.target.files[0]));
  drop.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('file').click(); } });
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => e.dataTransfer.files[0] && readFile(e.dataTransfer.files[0]));

  function cellToAwb(cell) {
    if (!cell) return '';
    let v = cell.v;
    if (typeof v === 'number') v = (Number.isInteger(v) && Math.abs(v) < 1e21) ? v.toFixed(0) : (cell.w || String(v));
    return String(v == null ? '' : v).trim();
  }

  async function readFile(file) {
    $('run-error').hidden = true;
    if (!/\.(xlsx|xls|csv)$/i.test(file.name)) { showError('Choose an .xlsx, .xls or .csv file.'); return; }
    try {
      const buf = await file.arrayBuffer();
      const wb = /\.csv$/i.test(file.name)
        ? XLSX.read(new TextDecoder().decode(buf), { type: 'string', raw: true })
        : XLSX.read(buf, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
      const seen = new Set(); let dup = 0; const list = [];
      for (let r = 1; r <= range.e.r; r++) {                 // row 2 onwards, column A
        const awb = cellToAwb(ws[XLSX.utils.encode_cell({ r, c: 0 })]).toUpperCase();
        if (!awb) continue;
        if (seen.has(awb)) { dup++; continue; }
        seen.add(awb); list.push(awb);
      }
      AWBS = { fwd: list.filter(a => !Tracker.isReverse(a)), rev: list.filter(a => Tracker.isReverse(a)) };
      $('file-name').textContent = file.name;
      $('c-total').textContent = list.length + dup;
      $('c-fwd').textContent = AWBS.fwd.length;
      $('c-rev').textContent = AWBS.rev.length;
      $('c-dup').textContent = dup;
      $('counts').hidden = false;
      $('btn-start').disabled = list.length === 0;
      if (!list.length) showError('No AWB numbers found in column A from row 2.');
    } catch (e) { showError('Could not read the file: ' + e.message); }
  }

  function showError(t) { $('run-error').textContent = t; $('run-error').hidden = false; }

  /* ======================= RUN ======================= */
  let RUNNING = false;

  function setLane(k, done, total, stats) {
    const lane = $('lane-' + k);
    const pct = total ? (done / total) * 100 : 0;
    lane.querySelector('.fill').style.width = pct + '%';
    lane.querySelector('.parcel').style.left = 'calc(' + pct + '% - ' + (pct / 100 * 18) + 'px)';
    $('n-' + k).textContent = done + ' / ' + total;
    $('f-' + k).textContent = stats || '';
  }

  function tally(rows) {
    let ok = 0, nf = 0, bad = 0;
    rows.forEach(r => {
      if (!r) { bad++; return; }
      const s = r.status_display;
      if (s === 'Not Found') nf++; else if (/^(TOKEN EXPIRED|NO TOKEN|ERROR|NOT TRACKED)/.test(s)) bad++; else ok++;
    });
    return { ok, nf, bad };
  }

  async function runSide(k, list) {
    const headers = k === 'fwd' ? Tracker.FORWARD_HEADERS : Tracker.REVERSE_HEADERS;
    const fn = k === 'fwd' ? Tracker.trackForward : Tracker.trackReverse;
    const label = k === 'fwd' ? 'Forward' : 'Reverse';
    const info = { status: '', user: readLoginForm()[k].user };
    if (!list.length) { setLane(k, 0, 0, 'No ' + label.toLowerCase() + ' AWBs in this file.'); return { rows: [], info }; }

    setLane(k, 0, list.length, 'Logging in…');
    let token;
    try { token = await getToken(k, false); setBlockStatus(k, 'Login works.', true); }
    catch (e) {
      setBlockStatus(k, e.message, false);
      info.status = 'Login failed: ' + e.message;
      setLane(k, 0, list.length, info.status);
      return { rows: list.map(a => { const r = {}; headers.forEach(h => r[h] = ''); r['AWB Number'] = a; r.status_display = 'NO TOKEN'; return r; }), info };
    }

    let done = 0;
    const onDone = () => { done++; if (done % 3 === 0 || done === list.length) setLane(k, done, list.length, 'Tracking…'); };
    let rows = await Tracker.runPool(list, awb => fn(awb, token), CFG.THREADS, onDone, () => STOP);
    const mk = (awb, status) => { const r = {}; headers.forEach(h => r[h] = ''); r['AWB Number'] = awb; r.status_display = status; return r; };
    rows = rows.map((r, i) => !r ? mk(list[i], 'NOT TRACKED (stopped)') : r.__error ? mk(list[i], 'ERROR') : r);

    // token expired -> fresh login once, retry those AWBs
    const expiredIdx = rows.map((r, i) => r && r.status_display === 'TOKEN EXPIRED' ? i : -1).filter(i => i >= 0);
    if (expiredIdx.length && !STOP) {
      setLane(k, done, list.length, expiredIdx.length + ' hit an expired token. Logging in again…');
      try {
        token = await getToken(k, true);
        const again = await Tracker.runPool(expiredIdx.map(i => list[i]), awb => fn(awb, token), 5, () => {}, () => STOP);
        expiredIdx.forEach((idx, j) => { if (again[j] && !again[j].__error) rows[idx] = again[j]; });
      } catch (e) { /* keep TOKEN EXPIRED rows */ }
    }

    const t = tally(rows);
    info.status = (STOP ? 'Stopped. ' : 'Done. ') + t.ok + ' tracked, ' + t.nf + ' not found' + (t.bad ? ', ' + t.bad + ' failed' : '');
    setLane(k, done, list.length, info.status);
    return { rows, info };
  }

  $('btn-start').onclick = async () => {
    $('run-error').hidden = true; $('done').hidden = true;
    // re-check the licence right before a run
    LIC = await Licence.refresh();
    if (!LIC) { show('screen-signin'); return; }
    renderChip();
    if (!Licence.allowed(LIC)) { lockToSubscribe(); return; }

    RUNNING = true; STOP = false;
    $('btn-start').disabled = true; $('btn-stop').hidden = false; $('lanes').hidden = false;
    const started = new Date();
    try {
      const [F, R] = await Promise.all([runSide('fwd', AWBS.fwd), runSide('rev', AWBS.rev)]);
      LAST_REPORT = buildReport(F, R, started);
      downloadReport();
      $('done-text').textContent = 'Report downloaded to your Downloads folder, inside "Eegai AWB Tracking": ' + LAST_REPORT.name;
      $('done').hidden = false;
    } catch (e) { showError(e.message); }
    finally {
      RUNNING = false;
      $('btn-start').disabled = false; $('btn-stop').hidden = true;
    }
  };

  $('btn-stop').onclick = () => { STOP = true; $('btn-stop').hidden = true; };

  /* ======================= OUTPUT ======================= */
  function pad(n) { return String(n).padStart(2, '0'); }

  function sheetFrom(rows, headers) {
    const ws = XLSX.utils.json_to_sheet(rows, { header: headers });
    ws['!cols'] = headers.map(h => ({ wch: h === 'order_track_history' ? 70 : h === 'address' ? 45 : Math.max(12, h.length + 2) }));
    ws['!autofilter'] = { ref: ws['!ref'] };
    ws['!freeze'] = { xSplit: 1, ySplit: 1 };
    return ws;
  }

  function buildReport(F, R, started) {
    const d = new Date();
    const stamp = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + '_' + pad(d.getHours()) + '-' + pad(d.getMinutes());
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheetFrom(F.rows, Tracker.FORWARD_HEADERS), 'Forward');
    XLSX.utils.book_append_sheet(wb, sheetFrom(R.rows, Tracker.REVERSE_HEADERS), 'Reverse');
    const secs = Math.round((d - started) / 1000);
    const summary = XLSX.utils.aoa_to_sheet([
      ['Forward Login', ''],
      ['Username', F.info.user || ''],
      ['Status', F.info.status],
      ['AWBs', F.rows.length],
      ['', ''],
      ['Reverse Login', ''],
      ['Username', R.info.user || ''],
      ['Status', R.info.status],
      ['AWBs', R.rows.length],
      ['', ''],
      ['Run started', started.toLocaleString()],
      ['Time taken', Math.floor(secs / 60) + ' min ' + (secs % 60) + ' s'],
      ['Tracked by', LIC ? LIC.email : '']
    ]);
    summary['!cols'] = [{ wch: 16 }, { wch: 60 }];
    XLSX.utils.book_append_sheet(wb, summary, 'Login');
    const bytes = XLSX.write(wb, { bookType: 'xlsx', type: 'array', compression: true });
    return { name: 'Shadowfax_AWB_Tracking_' + stamp + '.xlsx', bytes };
  }

  function downloadReport() {
    if (!LAST_REPORT) return;
    const blob = new Blob([LAST_REPORT.bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({ url, filename: 'Eegai AWB Tracking/' + LAST_REPORT.name, saveAs: false, conflictAction: 'uniquify' },
      () => setTimeout(() => URL.revokeObjectURL(url), 60000));
  }
  $('btn-download').onclick = downloadReport;

  window.addEventListener('beforeunload', e => { if (RUNNING) { e.preventDefault(); e.returnValue = ''; } });

  /* ======================= START ======================= */
  boot().then(() => { if (LIC) loadLogins(); });
})();
