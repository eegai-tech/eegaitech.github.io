/* Saved DC portal logins.
   The logins are encrypted (AES-GCM) and kept in a browser cookie on a private,
   never-requested path of saruman.shadowfax.in. The encryption key lives in the
   extension's own storage.
   - Kept for about 13 months (renewed every time the tracker opens).
   - "Clear browsing data > Cookies and other site data" deletes them.
   - The "Delete saved logins" button deletes them too.
   The cookie path is never visited, so the cookie is never sent to any server. */
const CredStore = (() => {
  const URL_ = 'https://saruman.shadowfax.in/__eegai_awb_vault__';
  const PATH = '/__eegai_awb_vault__';
  const NAME = 'eegai_awb_logins';
  const KEY_NAME = 'eegai_awb_vault_key';
  const DAYS = 399;

  const b64u = (bytes) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), c => c.charCodeAt(0));

  async function getKey() {
    const got = await chrome.storage.local.get(KEY_NAME);
    let raw = got[KEY_NAME];
    if (!raw) {
      raw = b64u(crypto.getRandomValues(new Uint8Array(32)));
      await chrome.storage.local.set({ [KEY_NAME]: raw });
    }
    return crypto.subtle.importKey('raw', unb64u(raw), 'AES-GCM', false, ['encrypt', 'decrypt']);
  }

  async function save(obj) {
    const key = await getKey();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key,
      new TextEncoder().encode(JSON.stringify(obj))));
    const packed = new Uint8Array(iv.length + ct.length);
    packed.set(iv); packed.set(ct, iv.length);
    const set = await chrome.cookies.set({
      url: URL_, name: NAME, value: b64u(packed), path: PATH,
      secure: true, httpOnly: true, sameSite: 'strict',
      expirationDate: Math.floor(Date.now() / 1000) + DAYS * 86400
    });
    if (!set) throw new Error('The browser blocked saving. Allow cookies for saruman.shadowfax.in and try again.');
  }

  async function load() {
    const c = await chrome.cookies.get({ url: URL_, name: NAME });
    if (!c || !c.value) return null;
    try {
      const packed = unb64u(c.value);
      const key = await getKey();
      const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: packed.slice(0, 12) }, key, packed.slice(12));
      const obj = JSON.parse(new TextDecoder().decode(pt));
      save(obj).catch(() => {});           // renew the expiry date
      return obj;
    } catch (e) {
      return null;                          // key changed or data damaged
    }
  }

  async function clear() {
    await chrome.cookies.remove({ url: URL_, name: NAME });
  }

  return { save, load, clear };
})();
