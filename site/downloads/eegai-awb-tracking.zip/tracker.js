/* Shadowfax AWB tracking – JavaScript port of the Python / Apps Script v6 logic.
   Forward: manifests/awbs/details  +  ecommerce/track/v2/{awb}/
   Reverse: manifests/awbs/details  +  pickup/track/{awb}/                       */
const Tracker = (() => {
  const API = EEGAI_CONFIG.API;
  const RETRY_CODES = new Set([500, 502, 503, 429]);
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const backoff = (attempt) => 1000 * Math.pow(2, attempt - 1) + Math.random() * 500;
  const g = (o, k) => (o && o[k] != null ? o[k] : '');

  function isReverse(awb) { return String(awb).trim().toUpperCase().startsWith('R'); }

  async function login(username, password) {
    let lastErr = 'No response from Shadowfax';
    for (let attempt = 1; attempt <= EEGAI_CONFIG.MAX_RETRIES; attempt++) {
      try {
        const r = await fetch(API.LOGIN, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({ username, password }),
          credentials: 'omit'
        });
        const text = await r.text();
        let data = {}; try { data = JSON.parse(text); } catch (e) { /* not JSON */ }
        if (r.status === 200) {
          const token = data.token || data.auth_token || data.key;
          if (token) return token;
          throw new Error('Login worked but no token came back. Shadowfax may be asking for an OTP; paste a token instead.');
        }
        lastErr = 'Login failed (HTTP ' + r.status + '): ' + (data.message || data.detail || data.error || text.slice(0, 120));
        if (!RETRY_CODES.has(r.status)) throw new Error(lastErr);
      } catch (e) {
        if (!/HTTP 5|HTTP 429|Failed to fetch/.test(e.message)) throw e;
        lastErr = e.message;
      }
      await sleep(backoff(attempt));
    }
    throw new Error(lastErr);
  }

  async function getJson(url, token) {
    const headers = { 'Authorization': 'Token ' + token, 'Accept': 'application/json' };
    for (let attempt = 1; attempt <= EEGAI_CONFIG.MAX_RETRIES; attempt++) {
      try {
        const r = await fetch(url, { headers, credentials: 'omit' });
        if (r.status === 401 || r.status === 403) return { code: r.status, data: null, expired: true };
        if (r.status === 404) return { code: 404, data: null, expired: false };
        if (RETRY_CODES.has(r.status)) { await sleep(backoff(attempt)); continue; }
        if (r.status === 200) {
          try { return { code: 200, data: await r.json(), expired: false }; }
          catch (e) { return { code: 200, data: null, expired: false }; }
        }
        return { code: r.status, data: null, expired: false };
      } catch (e) {
        await sleep(1000 * attempt);
      }
    }
    return { code: 'NO_RESP', data: null, expired: false };
  }

  /* ---------- history builders ---------- */
  function forwardHistory(histories) {
    const lines = (histories || []).map(h => {
      const loc = h.warehouse_name ? ' (' + h.warehouse_name + ')' : '';
      return [g(h, 'time') + ' — ' + g(h, 'text') + loc, g(h, 'text') + loc];
    });
    return {
      last_event: lines.length ? lines[0][0] : '',
      last_event_update: lines.length ? lines[0][1] : '',
      order_track_history: lines.map(l => l[0]).join('\n')
    };
  }

  function reverseHistory(histories) {
    const lines = (histories || []).map(h => {
      const ev = h.state || h.remarks || '';
      const rem = h.remarks && h.state ? ' (' + h.remarks + ')' : '';
      const loc = h.current_location ? ' [' + h.current_location + ']' : '';
      return [g(h, 'created_at') + ' — ' + ev + rem + loc, ev + rem + loc];
    });
    const n = lines.length;
    return {
      last_event: n ? lines[0][0] : '',
      last_event_update: n ? lines[0][1] : '',
      order_track_history: lines.map(l => l[0]).join('\n'),
      First_event: n ? lines[n - 1][0] : '',
      First_event_update: n ? lines[n - 1][1] : ''
    };
  }

  /* ---------- forward ---------- */
  const FORWARD_HEADERS = [
    'AWB Number', 'status_display', 'next_location', 'mm_code', 'current_location',
    'awb_status', 'runsheet_id', 'rider_name', 'delivery_pincode', 'client',
    'payment_mode', 'order_status', 'attempt_number', 'last_updated', 'hub_name',
    'product_name', 'address', 'order_tag_details',
    'last_event', 'last_event_update', 'order_track_history'
  ];

  function blank(headers, awb, status) {
    const row = {}; headers.forEach(h => row[h] = '');
    row['AWB Number'] = awb;
    if (status) row.status_display = status;
    return row;
  }

  async function trackForward(awb, token) {
    if (!token) return blank(FORWARD_HEADERS, awb, 'NO TOKEN');
    let details = null, req = null, histories = [], expired = false;

    let r = await getJson(API.DETAILS + '?awb_number=' + encodeURIComponent(awb), token);
    if (r.expired) expired = true;
    else if (r.code === 200 && r.data) { const d = r.data.data || {}; if (d.awb_number) details = d; }

    r = await getJson(API.FWD + encodeURIComponent(awb) + '/', token);
    if (r.expired) expired = true;
    else if (r.code === 200 && r.data) {
      const q = r.data.request || {}; if (q.awb_number) req = q;
      if (Array.isArray(r.data.request_histories)) histories = r.data.request_histories;
    }

    if (expired) return blank(FORWARD_HEADERS, awb, 'TOKEN EXPIRED');
    if (!details && !req) return blank(FORWARD_HEADERS, awb, 'Not Found');

    const D = details || {}, Q = req || {};
    const items = ((D.manifest_details || {}).item_details) || [];
    const self = items.find(x => x.awb_number === awb) || {};
    const rider = Q.rider_details || {};
    const products = (Q.products || []).map(p => p.product_name || '').join('; ');
    const tags = (Q.order_tag_details || []).map(t =>
      (t.tag || '') + (t.amount ? ' (' + t.amount + ')' : '') + (t.info_text ? ' - ' + t.info_text : '')).join('; ');

    return Object.assign(blank(FORWARD_HEADERS, awb), {
      status_display: g(D, 'status_display'),
      next_location: g(D, 'next_location'),
      mm_code: g(D, 'mm_code'),
      current_location: g(D, 'current_location'),
      awb_status: g(D, 'awb_status'),
      runsheet_id: g(D, 'runsheet_id'),
      rider_name: D.rider_name || rider.name || '',
      delivery_pincode: self.delivery_pincode || (D.current_bin || {}).name || '',
      client: self.client || D.client_name || Q.client || '',
      payment_mode: g(Q, 'payment_mode'),
      order_status: g(Q, 'order_status'),
      attempt_number: g(Q, 'attempt_number'),
      last_updated: g(Q, 'last_updated'),
      hub_name: g(Q, 'hub_name'),
      product_name: products,
      address: g(Q, 'address'),
      order_tag_details: tags
    }, forwardHistory(histories));
  }

  /* ---------- reverse ---------- */
  const REVERSE_HEADERS = [
    'AWB Number', 'status_display', 'new_status_display', 'final_status_display',
    'next_location', 'current_location', 'awb_status', 'runsheet_id', 'rider_name',
    'client_name', 'customer_name', 'customer_city', 'customer_state', 'pincode',
    'product_name', 'return_type', 'return_reason', 'request_type', 'reference_code',
    'pickup_type', 'attempt_number', 'state_change_reason', 'address', 'aeging',
    'order_type_display',
    'last_event', 'last_event_update', 'order_track_history',
    'First_event', 'First_event_update'
  ];

  async function trackReverse(awb, token) {
    if (!token) return blank(REVERSE_HEADERS, awb, 'NO TOKEN');
    let details = null, req = null, histories = [], expired = false;

    let r = await getJson(API.DETAILS + '?awb_number=' + encodeURIComponent(awb), token);
    if (r.expired) expired = true;
    else if (r.code === 200 && r.data) { const d = r.data.data || {}; if (d.awb_number) details = d; }

    r = await getJson(API.REV + encodeURIComponent(awb) + '/', token);
    if (r.expired) expired = true;
    else if (r.code === 200 && r.data) {
      const q = r.data.request || {}; if (q.awb_number) req = q;
      if (Array.isArray(r.data.request_histories)) histories = r.data.request_histories;
    }

    if (expired) return blank(REVERSE_HEADERS, awb, 'TOKEN EXPIRED');
    if (!details && !req) return blank(REVERSE_HEADERS, awb, 'Not Found');

    const D = details || {}, Q = req || {};
    const cust = Q.customer_details || {};
    const item = Q.item_details || {};
    const prods = Q.products || [];

    return Object.assign(blank(REVERSE_HEADERS, awb), {
      status_display: Q.status_display || D.status_display || '',
      new_status_display: g(Q, 'new_status_display'),
      final_status_display: g(D, 'final_status_display'),
      next_location: D.next_location || item.next_location || '',
      current_location: D.current_location || item.current_location || '',
      awb_status: D.awb_status || Q.status || '',
      runsheet_id: g(D, 'runsheet_id'),
      rider_name: g(D, 'rider_name'),
      client_name: D.client_name || Q.client_name || '',
      customer_name: g(cust, 'customer_name'),
      customer_city: g(cust, 'customer_city'),
      customer_state: g(cust, 'customer_state'),
      pincode: g(cust, 'pincode'),
      product_name: prods.map(p => p.product_name || '').join('; '),
      return_type: g(Q, 'return_type'),
      return_reason: Q.return_reason || prods.filter(p => p.return_reason).map(p => p.return_reason).join('; '),
      request_type: g(Q, 'request_type'),
      reference_code: g(Q, 'reference_code'),
      pickup_type: g(Q, 'pickup_type'),
      attempt_number: g(Q, 'attempt_number'),
      state_change_reason: g(Q, 'state_change_reason'),
      address: g(Q, 'address'),
      aeging: g(Q, 'aeging'),
      order_type_display: g(Q, 'order_type_display')
    }, reverseHistory(histories));
  }

  /* ---------- pool runner ---------- */
  async function runPool(items, worker, threads, onDone, shouldStop) {
    const results = new Array(items.length);
    let next = 0;
    async function lane() {
      while (next < items.length && !shouldStop()) {
        const i = next++;
        try { results[i] = await worker(items[i]); }
        catch (e) { results[i] = { __error: e.message || 'error' }; }
        onDone(results[i], i);
      }
    }
    await Promise.all(Array.from({ length: Math.min(threads, items.length) }, lane));
    return results;
  }

  return { isReverse, login, trackForward, trackReverse, runPool, FORWARD_HEADERS, REVERSE_HEADERS };
})();
