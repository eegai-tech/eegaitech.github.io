/* Stable device ID: SHA-256 of general hardware traits (no personal data).
   Same value on the same computer, survives uninstall / reinstall,
   so the free trial cannot be restarted by reinstalling. */
async function eegaiDeviceId() {
  const parts = [];
  try {
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
    if (gl) {
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      parts.push(dbg ? gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) : '');
      parts.push(dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : '');
      parts.push(gl.getParameter(gl.MAX_TEXTURE_SIZE));
    }
  } catch (e) { /* ignore */ }
  parts.push(navigator.hardwareConcurrency || 0);
  parts.push(navigator.deviceMemory || 0);
  parts.push((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '');
  parts.push(screen.width * screen.height, screen.colorDepth);
  parts.push(Intl.DateTimeFormat().resolvedOptions().timeZone || '');
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(parts.join('|')));
  return 'D' + Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 40);
}
