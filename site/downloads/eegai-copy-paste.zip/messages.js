function eegaiErrorText(code) {
  const map = {
    SERVER_NOT_CONFIGURED: 'The licence server is not set up yet (config.js).',
    SIGN_IN_CANCELLED: 'Sign-in was cancelled. Try again.',
    access_denied: 'Sign-in was cancelled. Try again.',
    GOOGLE_TOKEN_INVALID: 'Google sign-in failed. Try again.',
    GOOGLE_CLIENT_MISMATCH: 'Sign-in is misconfigured (client ID). Contact support.',
    EMAIL_NOT_VERIFIED: 'Your Google e-mail is not verified.',
    UTR_INVALID: 'Enter the 12-digit UPI reference number from your payment app.',
    UTR_ALREADY_USED: 'This reference number was already used by another account.',
    SESSION_INVALID: 'Please sign in again.',
    DEVICE_INVALID: 'Could not identify this computer. Reload and try again.'
  };
  code = String(code || '');
  if (map[code]) return map[code];
  if (/did not approve|user cancelled|canceled|closed/i.test(code)) return map.SIGN_IN_CANCELLED;
  if (/Failed to fetch|NetworkError/i.test(code)) return 'No internet connection. Try again.';
  return 'Something went wrong: ' + code;
}
function eegaiDaysLeft(l) { return Math.max(0, Math.ceil((Number(l.trialEndsAt) - Date.now()) / 86400000)); }
function eegaiState(l) {
  if (!l) return 'signed_out';
  if (l.state === 'trial' && Date.now() >= Number(l.trialEndsAt)) return l.pendingUtr ? 'pending' : 'expired';
  return l.state;
}
