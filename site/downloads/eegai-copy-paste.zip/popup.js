const $ = (id) => document.getElementById(id);
let tab = null;
let key = null;

function siteKey(url) {
  try { const u = new URL(url); return u.hostname || 'local-files'; } catch (e) { return null; }
}
function setStatus(text, kind) {
  const s = $('status');
  s.textContent = text || '';
  s.className = 'status ' + (kind || '');
}
function paintSite(on) {
  $('siteToggle').checked = on;
  $('siteCard').classList.toggle('on', on);
  $('siteState').textContent = on ? 'Unlocked: copy, paste, select and right-click' : 'Locked: website rules apply';
}

function paintPlan(l) {
  const st = eegaiState(l);
  const plan = $('plan'), btn = $('planBtn');
  const set = (text, cls, label, page) => {
    $('planText').textContent = text;
    plan.className = 'plan ' + (cls || '');
    btn.hidden = !label;
    if (label) { btn.textContent = label; btn.onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: page }); window.close(); }; }
  };
  if (st === 'signed_out') set('Sign in to start your ' + EEGAI_CONFIG.TRIAL_DAYS + '-day free trial', 'bad', 'Sign in', 'welcome.html');
  else if (st === 'trial') { const d = eegaiDaysLeft(l); set('Free trial: ' + d + (d === 1 ? ' day' : ' days') + ' left', '', 'Upgrade ₹' + EEGAI_CONFIG.PRICE_INR, 'subscribe.html'); }
  else if (st === 'expired') set('Your free trial has ended', 'bad', 'Get lifetime ₹' + EEGAI_CONFIG.PRICE_INR, 'subscribe.html');
  else if (st === 'pending') set('Confirming your payment', '', 'View', 'subscribe.html');
  else if (st === 'premium') set('Premium: lifetime access', 'good');
  else if (st === 'other_device') set('Licence is active on another computer', 'bad', 'Help', 'subscribe.html');
  else if (st === 'blocked') set('Access disabled. Contact support.', 'bad');
  return st === 'premium' || st === 'trial';
}

async function init() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const s = await chrome.storage.local.get({ global: false, sites: {}, license: null });
  $('globalToggle').checked = s.global;

  const licensed = paintPlan(s.license);
  chrome.runtime.sendMessage({ type: 'lic-refresh' }).then((r) => { if (r && r.ok) paintPlan(r.license); }).catch(() => {});
  if (!licensed) {
    document.querySelector('main').classList.add('locked');
    $('globalToggle').disabled = true;
    $('siteName').textContent = siteKey(tab && tab.url) || 'This page';
    $('siteState').textContent = 'Start your trial or upgrade to unlock';
    return;
  }

  const supported = tab && /^(https?|file):/i.test(tab.url || '');
  if (!supported) {
    $('siteName').textContent = 'This page';
    $('siteState').textContent = 'Browser pages cannot be changed by extensions';
    return;
  }
  key = siteKey(tab.url);
  $('siteName').textContent = key;
  $('siteToggle').disabled = false;
  $('pasteBtn').disabled = false;
  $('copyPageBtn').disabled = false;
  paintSite(typeof s.sites[key] === 'boolean' ? s.sites[key] : s.global);

  // Is the content script running here? (tabs opened before install need a reload)
  chrome.tabs.sendMessage(tab.id, { type: 'eegai-ping' }, { frameId: 0 }).catch(() => {
    $('reloadHint').hidden = false;
  });
}

$('siteToggle').addEventListener('change', async (e) => {
  const on = e.target.checked;
  const s = await chrome.storage.local.get({ sites: {} });
  s.sites[key] = on;
  await chrome.storage.local.set({ sites: s.sites });
  paintSite(on);
  if (on) $('reloadHint').hidden = false;
  setStatus(on ? 'Unlocked on ' + key : 'Locked on ' + key, on ? 'ok' : '');
});

$('globalToggle').addEventListener('change', async (e) => {
  await chrome.storage.local.set({ global: e.target.checked });
  const s = await chrome.storage.local.get({ global: false, sites: {} });
  if (key) paintSite(typeof s.sites[key] === 'boolean' ? s.sites[key] : s.global);
  setStatus(e.target.checked ? 'Unlocked on all websites' : 'All-websites unlock turned off', e.target.checked ? 'ok' : '');
});

$('reloadBtn').addEventListener('click', () => { chrome.tabs.reload(tab.id); window.close(); });

$('pasteBtn').addEventListener('click', async () => {
  let text = '';
  try { text = await navigator.clipboard.readText(); } catch (e) {}
  const r = text
    ? await chrome.runtime.sendMessage({ type: 'popup-insert', tabId: tab.id, text })
    : await chrome.runtime.sendMessage({ type: 'popup-force-paste', tabId: tab.id });
  if (r && r.ok) window.close();
  else setStatus('Click inside a text box on the page first', 'err');
});

$('copyPageBtn').addEventListener('click', async () => {
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'eegai-page-text' }, { frameId: 0 });
    const text = (r && r.text) || '';
    if (!text.trim()) return setStatus('No text found on this page', 'err');
    await navigator.clipboard.writeText(text);
    setStatus('Copied ' + text.length.toLocaleString() + ' characters', 'ok');
  } catch (e) {
    setStatus('Reload the page, then try again', 'err');
  }
});

init();
