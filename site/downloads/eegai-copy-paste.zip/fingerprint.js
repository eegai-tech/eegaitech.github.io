/* Stable, privacy-friendly device ID: a SHA-256 hash of general hardware traits.
   Same value in Chrome and Edge on the same computer; survives reinstall. */
async function eegaiDeviceId() {
  const parts = [
    navigator.platform || '',
    navigator.hardwareConcurrency || '',
    navigator.deviceMemory || '',
    Intl.DateTimeFormat().resolvedOptions().timeZone || ''
  ];
  try {
    const gl = document.createElement('canvas').getContext('webgl');
    const ext = gl && gl.getExtension('WEBGL_debug_renderer_info');
    if (ext) parts.push(gl.getParameter(ext.UNMASKED_VENDOR_WEBGL), gl.getParameter(ext.UNMASKED_RENDERER_WEBGL));
  } catch (e) {}
  try {
    const h = await navigator.userAgentData.getHighEntropyValues(['architecture', 'bitness', 'model']);
    parts.push(navigator.userAgentData.platform, h.architecture, h.bitness, h.model);
  } catch (e) {}
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(parts.join('|')));
  return 'D' + [...new Uint8Array(buf)].slice(0, 16).map((b) => b.toString(16).padStart(2, '0')).join('');
}
