/* Eegai Copy & Paste – background service worker (v2, with licence) */
importScripts('config.js');
const C = EEGAI_CONFIG;

const MENU = { ROOT: 'eegai-root', PASTE: 'eegai-force-paste', COPY: 'eegai-force-copy', SEP: 'eegai-sep', TOGGLE: 'eegai-toggle-site' };
const CHECK_EVERY_MS = 6 * 60 * 60 * 1000; // server re-check
const lastFrame = {};

/* =================== LICENCE =================== */
async function getLic() { return (await chrome.storage.local.get({ license: null })).license; }

function licensedNow(l) {
  if (!l) return false;
  if (l.state === 'premium') return true;
  if (l.state === 'trial') return Date.now() < Number(l.trialEndsAt);
  return false;
}

async function saveLic(l) {
  const licensed = licensedNow(l);
  await chrome.storage.local.set({ license: l, licensed });
  refreshAllBadges();
  if (l && !licensed && (l.state === 'trial' || l.state === 'expired')) maybeShowPaywall();
  return l;
}

async function maybeShowPaywall() {
  const today = new Date().toDateString();
  const { paywallShown } = await chrome.storage.local.get({ paywallShown: '' });
  if (paywallShown === today) return;
  await chrome.storage.local.set({ paywallShown: today });
  chrome.tabs.create({ url: 'subscribe.html' });
}

async function api(action, data) {
  if (C.SERVER_URL.includes('PASTE_')) throw new Error('SERVER_NOT_CONFIGURED');
  const res = await fetch(C.SERVER_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(Object.assign({ action, version: chrome.runtime.getManifest().version }, data))
  });
  const j = await res.json();
  if (!j.ok) throw new Error(j.error || 'SERVER_ERROR');
  return j;
}

function fromServer(j, deviceId, session) {
  return {
    state: j.state, email: j.email, trialEndsAt: j.trialEndsAt, trialDays: j.trialDays,
    orderId: j.orderId, pendingUtr: j.pendingUtr || '', support: j.support || '',
    session: j.session || session, deviceId, checkedAt: Date.now()
  };
}

async function googleAccessToken() {
  if (C.GOOGLE_CLIENT_ID.includes('PASTE-')) throw new Error('SERVER_NOT_CONFIGURED');
  const url = 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({
    client_id: C.GOOGLE_CLIENT_ID,
    response_type: 'token',
    redirect_uri: chrome.identity.getRedirectURL(),
    scope: 'openid email',
    prompt: 'select_account'
  });
  const back = await chrome.identity.launchWebAuthFlow({ url, interactive: true });
  const p = new URLSearchParams(new URL(back).hash.slice(1));
  const token = p.get('access_token');
  if (!token) throw new Error(p.get('error') || 'SIGN_IN_CANCELLED');
  return token;
}

async function signIn(deviceId) {
  const accessToken = await googleAccessToken();
  const browser = /Edg\//.test(navigator.userAgent) ? 'Edge' : 'Chrome';
  const j = await api('login', { accessToken, deviceId, browser });
  return saveLic(fromServer(j, deviceId));
}

async function refreshLic(force) {
  const l = await getLic();
  if (!l || !l.session) return l;
  if (!force && Date.now() - (l.checkedAt || 0) < CHECK_EVERY_MS) return saveLic(l);
  try {
    const j = await api('status', { session: l.session });
    return saveLic(fromServer(j, l.deviceId, l.session));
  } catch (e) {
    if (/SESSION_INVALID/.test(e.message)) {
      await chrome.storage.local.set({ license: null, licensed: false });
      refreshAllBadges();
      return null;
    }
    return saveLic(l); // offline: keep cached licence (trial still ends on time)
  }
}

async function submitPayment(utr, upi) {
  const l = await getLic();
  if (!l) throw new Error('SIGNED_OUT');
  const j = await api('submitPayment', { session: l.session, utr, upi });
  return saveLic(fromServer(j, l.deviceId, l.session));
}

async function requireLicence() {
  const { licensed, license } = await chrome.storage.local.get({ licensed: false, license: null });
  if (licensed) return true;
  chrome.tabs.create({ url: license ? 'subscribe.html' : 'welcome.html' });
  return false;
}

chrome.alarms.create('eegai-licence', { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'eegai-licence') refreshLic(false); });

/* =================== SETTINGS & BADGE =================== */
function getSettings() { return chrome.storage.local.get({ global: false, sites: {}, licensed: false }); }
function siteKey(url) { try { const u = new URL(url); return u.hostname || 'local-files'; } catch (e) { return null; } }
function isWebUrl(url) { return /^(https?|file):/i.test(url || ''); }

async function refreshBadge(tabId, url) {
  const s = await getSettings();
  let text = '', color = '#1f9d55';
  if (!s.licensed) { text = '!'; color = '#c2412d'; }
  else if (isWebUrl(url)) {
    const k = siteKey(url);
    if (typeof s.sites[k] === 'boolean' ? s.sites[k] : s.global) text = 'ON';
  }
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
}
async function refreshAllBadges() {
  (await chrome.tabs.query({})).forEach((t) => refreshBadge(t.id, t.url));
}
chrome.tabs.onUpdated.addListener((tabId, info, tab) => { if (info.url || info.status === 'loading') refreshBadge(tabId, tab.url); });
chrome.tabs.onActivated.addListener(async ({ tabId }) => { try { const t = await chrome.tabs.get(tabId); refreshBadge(tabId, t.url); } catch (e) {} });
chrome.tabs.onRemoved.addListener((tabId) => { delete lastFrame[tabId]; });
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && (c.global || c.sites)) refreshAllBadges(); });

async function toggleSite(tab) {
  if (!tab || !isWebUrl(tab.url) || !(await requireLicence())) return;
  const key = siteKey(tab.url);
  const s = await getSettings();
  const now = !(typeof s.sites[key] === 'boolean' ? s.sites[key] : s.global);
  s.sites[key] = now;
  await chrome.storage.local.set({ sites: s.sites });
  toast(tab.id, now ? 'Copy & paste unlocked on ' + key : 'Copy & paste locked on ' + key, now ? 'ok' : '');
}

/* =================== CLIPBOARD (offscreen) =================== */
let creating = null;
async function ensureOffscreen() {
  if (chrome.runtime.getContexts) {
    const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (ctx.length) return;
  }
  if (!creating) {
    creating = chrome.offscreen.createDocument({
      url: 'offscreen.html', reasons: ['CLIPBOARD'],
      justification: 'Read and write the clipboard for force copy and force paste'
    }).catch((e) => { if (!String(e).includes('single offscreen')) throw e; })
      .finally(() => { creating = null; });
  }
  return creating;
}
async function readClipboard() {
  await ensureOffscreen();
  const r = await chrome.runtime.sendMessage({ target: 'eegai-offscreen', type: 'read' });
  return (r && r.text) || '';
}
async function writeClipboard(text) {
  await ensureOffscreen();
  const r = await chrome.runtime.sendMessage({ target: 'eegai-offscreen', type: 'write', text });
  return !!(r && r.ok);
}

/* =================== ACTIONS =================== */
function toast(tabId, text, kind) {
  chrome.tabs.sendMessage(tabId, { type: 'eegai-toast', text, kind }, { frameId: 0 }).catch(() => {});
}
async function insertIntoTab(tabId, frameId, text) {
  if (!text) { toast(tabId, 'Clipboard is empty or has no text', 'err'); return false; }
  const fid = typeof frameId === 'number' ? frameId : (lastFrame[tabId] ?? 0);
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: 'eegai-insert', text }, { frameId: fid });
    if (r && r.ok) { toast(tabId, 'Pasted ' + text.length + ' characters', 'ok'); return true; }
  } catch (e) {}
  toast(tabId, 'Click inside a text box first, then paste again', 'err');
  return false;
}
async function forcePaste(tabId, frameId) {
  if (!(await requireLicence())) return false;
  let text = '';
  try { text = await readClipboard(); } catch (e) {}
  return insertIntoTab(tabId, frameId, text);
}
async function forceCopy(tabId, frameId, fallback) {
  if (!(await requireLicence())) return;
  let text = '';
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: 'eegai-get-selection' }, { frameId: frameId || 0 });
    text = (r && r.text) || '';
  } catch (e) {}
  if (!text) text = fallback || '';
  if (!text) { toast(tabId, 'Select some text first', 'err'); return; }
  const ok = await writeClipboard(text).catch(() => false);
  toast(tabId, ok ? 'Copied ' + text.length + ' characters' : 'Could not copy. Try again', ok ? 'ok' : 'err');
}

/* =================== INSTALL =================== */
chrome.runtime.onInstalled.addListener((details) => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: MENU.ROOT, title: 'Eegai Copy & Paste', contexts: ['all'] });
    chrome.contextMenus.create({ id: MENU.PASTE, parentId: MENU.ROOT, title: 'Force paste here', contexts: ['editable'] });
    chrome.contextMenus.create({ id: MENU.COPY, parentId: MENU.ROOT, title: 'Force copy selected text', contexts: ['selection'] });
    chrome.contextMenus.create({ id: MENU.SEP, parentId: MENU.ROOT, type: 'separator', contexts: ['all'] });
    chrome.contextMenus.create({ id: MENU.TOGGLE, parentId: MENU.ROOT, title: 'Unlock / lock this website', contexts: ['all'] });
  });
  injectIntoOpenTabs();
  refreshAllBadges();
  if (details.reason === 'install') chrome.tabs.create({ url: 'welcome.html' });
});
chrome.runtime.onStartup.addListener(() => refreshLic(true));

async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const t of tabs) {
    chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['inject.js'], world: 'MAIN' }).catch(() => {});
    chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: true }, files: ['content.js'] }).catch(() => {});
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab) return;
  if (info.menuItemId === MENU.PASTE) forcePaste(tab.id, info.frameId);
  else if (info.menuItemId === MENU.COPY) forceCopy(tab.id, info.frameId, info.selectionText);
  else if (info.menuItemId === MENU.TOGGLE) toggleSite(tab);
});

chrome.commands.onCommand.addListener(async (cmd, tab) => {
  if (!tab) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  if (cmd === 'force-paste') forcePaste(tab.id);
  else if (cmd === 'toggle-site') toggleSite(tab);
});

/* =================== MESSAGES =================== */
function reply(promise, sendResponse) {
  promise.then((license) => sendResponse({ ok: true, license }))
    .catch((e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target === 'eegai-offscreen') return;
  switch (msg.type) {
    case 'eegai-focus':
      if (sender.tab) lastFrame[sender.tab.id] = sender.frameId;
      return;
    case 'lic-signin': return reply(signIn(msg.deviceId), sendResponse);
    case 'lic-refresh': return reply(refreshLic(!!msg.force), sendResponse);
    case 'lic-pay': return reply(submitPayment(msg.utr, msg.upi), sendResponse);
    case 'lic-signout':
      return reply(chrome.storage.local.set({ license: null, licensed: false }).then(() => { refreshAllBadges(); return null; }), sendResponse);
    case 'popup-insert':
      requireLicence().then((ok) => ok ? insertIntoTab(msg.tabId, undefined, msg.text) : false).then((ok) => sendResponse({ ok }));
      return true;
    case 'popup-force-paste':
      forcePaste(msg.tabId).then((ok) => sendResponse({ ok }));
      return true;
  }
});
