# Eegai Copy & Paste (Chrome & Edge extension) v2

**Before loading:** fill in `SERVER_URL` and `GOOGLE_CLIENT_ID` in `config.js`. See PUBLISHING-GUIDE.md.

Unlocks copy, paste, text selection and right-click on websites that block them,
and can force-paste into text boxes that refuse Ctrl+V.

## Install in Edge
1. Unzip this folder.
2. Open `edge://extensions`.
3. Turn on **Developer mode** (left sidebar / bottom-left).
4. Click **Load unpacked** and pick the `eegai-copy-paste` folder.
5. Pin the icon from the puzzle-piece menu in the toolbar.

## How to use
- Open a website that blocks copy/paste, click the Eegai icon, and switch the site **on**.
  The badge shows **ON** for unlocked sites. Reload the page if it still blocks.
- **Force paste**: right-click a text box → *Eegai Copy & Paste → Force paste here*,
  or press **Alt+Shift+V**, or use the popup button.
- **Force copy**: select text → right-click → *Force copy selected text*.
- **Copy all text on this page**: popup button, for pages where selecting is impossible.
- **Alt+Shift+U** unlocks / locks the current site. Change shortcuts at `edge://extensions/shortcuts`.

## Notes
- Sites are locked by default so normal sites (Google Docs, Gmail, Sheets) keep their own
  copy/paste behaviour. Turn on "Unlock on all websites" only if you want it everywhere.
- Browser pages (`edge://`, the Add-ons store) cannot be changed by any extension.
- For local HTML files, enable *Allow access to file URLs* on the extension's details page.
