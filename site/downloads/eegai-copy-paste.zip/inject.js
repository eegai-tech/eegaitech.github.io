/* Eegai Copy & Paste – runs in the page's own JS world at document_start.
   While a site is unlocked, the page's own copy/paste/selection/right-click
   blockers are stopped before they can run. */
(() => {
  'use strict';
  if (window.__eegaiCopyPaste) return;
  try { Object.defineProperty(window, '__eegaiCopyPaste', { value: true }); } catch (e) {}

  let on = false;

  const BLOCKED = new Set([
    'copy', 'cut', 'paste', 'contextmenu', 'selectstart',
    'beforecopy', 'beforecut', 'beforepaste'
  ]);
  const CLIP_KEYS = new Set(['c', 'v', 'x', 'a']);

  // Should the page be prevented from cancelling this event?
  function isProtected(ev) {
    if (!on || !ev) return false;
    const t = ev.type;
    if (BLOCKED.has(t)) return true;
    if (t === 'keydown' || t === 'keypress' || t === 'keyup') {
      const k = String(ev.key || '').toLowerCase();
      if ((ev.ctrlKey || ev.metaKey) && (CLIP_KEYS.has(k) || k === 'insert')) return true;
      if (ev.shiftKey && k === 'insert') return true;
      return false;
    }
    if (t === 'beforeinput') {
      return /^(insertFromPaste|insertFromDrop|deleteByCut)/.test(ev.inputType || '');
    }
    return false;
  }

  // 1) Page code can still run, but cannot cancel protected events.
  const origPreventDefault = Event.prototype.preventDefault;
  Event.prototype.preventDefault = function () {
    if (isProtected(this)) return;
    return origPreventDefault.apply(this, arguments);
  };

  const rv = Object.getOwnPropertyDescriptor(Event.prototype, 'returnValue');
  if (rv && rv.set && rv.configurable) {
    Object.defineProperty(Event.prototype, 'returnValue', {
      configurable: true,
      enumerable: rv.enumerable,
      get: rv.get,
      set(v) {
        if (v === false && isProtected(this)) return;
        rv.set.call(this, v);
      }
    });
  }

  // 2) Stop page listeners (incl. oncopy="return false" attributes) entirely.
  //    Registered at document_start, so this runs before any page listener.
  const stopper = (ev) => { if (on) ev.stopImmediatePropagation(); };
  BLOCKED.forEach((type) => window.addEventListener(type, stopper, true));

  // 3) State comes from the extension's isolated content script.
  document.addEventListener('eegai-cp-state', (ev) => { on = ev.detail === true; }, true);
  document.dispatchEvent(new CustomEvent('eegai-cp-hello'));
})();
