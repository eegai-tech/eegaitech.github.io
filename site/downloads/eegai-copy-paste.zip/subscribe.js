const $ = (id) => document.getElementById(id);
const C = EEGAI_CONFIG;
let lic = null, chosen = 0, poll = null;

// Admin contact (WhatsApp + phone)
const ADMIN_PHONE = C.ADMIN_PHONE || '9500400427';
const ADMIN_PHONE_INTL = '91' + ADMIN_PHONE.replace(/\D/g, '').slice(-10);

document.querySelectorAll('.amt').forEach((e) => { e.textContent = C.PRICE_INR; });
$('priceBig').textContent = C.PRICE_INR;

function drawQr() {
  const opt = C.UPI_OPTIONS[chosen];
  const qr = qrcode(0, 'M');
  qr.addData(eegaiUpiLink(opt, lic && lic.orderId));
  qr.make();
  $('qr').innerHTML = qr.createSvgTag({ cellSize: 6, margin: 2, scalable: true, alt: 'UPI QR code for ' + opt.upiId });
  $('upiId').textContent = opt.upiId;
  $('payee').textContent = 'Pays ' + opt.payee;
  [...$('tabs').children].forEach((b, i) => b.setAttribute('aria-selected', String(i === chosen)));
}

C.UPI_OPTIONS.forEach((o, i) => {
  const b = document.createElement('button');
  b.className = 'tab'; b.type = 'button'; b.setAttribute('role', 'tab'); b.textContent = o.label;
  b.addEventListener('click', () => { chosen = i; drawQr(); updateHelp(); });
  $('tabs').appendChild(b);
});

/* WhatsApp message pre-filled with the user's details */
function updateHelp() {
  const utr = ($('utr').value || (lic && lic.pendingUtr) || '').trim();
  const lines = [
    'Hi, I need help with my Eegai Copy & Paste payment.',
    '',
    'Gmail: ' + ((lic && lic.email) || '-'),
    'Order: ' + ((lic && lic.orderId) || '-'),
    'Paid to: ' + C.UPI_OPTIONS[chosen].upiId,
    'Amount: Rs ' + C.PRICE_INR,
    'UPI reference (UTR): ' + (utr || '-'),
    '',
    'I am attaching my payment screenshot.'
  ];
  $('waBtn').href = 'https://wa.me/' + ADMIN_PHONE_INTL + '?text=' + encodeURIComponent(lines.join('\n'));
  $('callBtn').href = 'tel:+' + ADMIN_PHONE_INTL;
}

function render(l) {
  lic = l;
  const st = eegaiState(l);
  ['payView', 'doneView', 'signinView'].forEach((v) => { $(v).hidden = true; });
  $('banner').hidden = true;
  updateHelp();

  if (st === 'signed_out') { $('signinView').hidden = false; return; }
  if (st === 'premium') { $('doneView').hidden = false; $('help').hidden = true; stopPoll(); return; }
  $('help').hidden = false;
  if (st === 'other_device' || st === 'blocked') {
    $('banner').hidden = false;
    $('banner').textContent = st === 'other_device'
      ? 'Your licence is active on another computer. Contact the admin on WhatsApp (95004 00427) with your Gmail to move it to this one.'
      : 'Access for this account is disabled. Contact the admin on WhatsApp (95004 00427).';
    return;
  }

  $('payView').hidden = false;
  $('email').textContent = l.email;
  $('order').textContent = l.orderId || '';
  $('headline').textContent = st === 'trial'
    ? 'Free trial: ' + eegaiDaysLeft(l) + ' days left'
    : 'Your free trial has ended';
  drawQr();

  if (l.pendingUtr) {
    $('utr').value = l.pendingUtr;
    $('pendingNote').hidden = false;
    $('pendingNote').textContent = 'Checking payment ' + l.pendingUtr + '. This page updates by itself.';
    updateHelp();
    startPoll();
  } else {
    $('pendingNote').hidden = true;
  }
}

function startPoll() {
  if (poll) return;
  poll = setInterval(async () => {
    const r = await chrome.runtime.sendMessage({ type: 'lic-refresh', force: true });
    if (r && r.ok) render(r.license);
  }, 20000);
}
function stopPoll() { if (poll) clearInterval(poll); poll = null; }

$('utr').addEventListener('input', (e) => {
  e.target.value = e.target.value.replace(/\D/g, '').slice(0, 12);
  updateHelp();
});

$('submit').addEventListener('click', async () => {
  const utr = $('utr').value.trim();
  if (!/^\d{12}$/.test(utr)) { $('msg').className = 'msg err'; $('msg').textContent = eegaiErrorText('UTR_INVALID'); return; }
  $('submit').disabled = true;
  $('msg').className = 'msg'; $('msg').textContent = 'Sending…';
  try {
    const r = await chrome.runtime.sendMessage({ type: 'lic-pay', utr, upi: C.UPI_OPTIONS[chosen].upiId });
    if (!r.ok) throw new Error(r.error);
    if (eegaiState(r.license) === 'premium') { render(r.license); return; }
    $('msg').className = 'msg ok';
    $('msg').textContent = 'Received. We are confirming your payment; this usually takes a few minutes. If it takes longer, WhatsApp the admin below.';
    render(r.license);
  } catch (e) {
    $('msg').className = 'msg err';
    $('msg').textContent = eegaiErrorText(e.message) + ' Need help? WhatsApp 95004 00427.';
  } finally { $('submit').disabled = false; }
});

$('copyUpi').addEventListener('click', async () => {
  await navigator.clipboard.writeText(C.UPI_OPTIONS[chosen].upiId);
  $('copyUpi').textContent = 'Copied';
  setTimeout(() => { $('copyUpi').textContent = 'Copy UPI ID'; }, 1500);
});
$('copyPhone').addEventListener('click', async () => {
  await navigator.clipboard.writeText(ADMIN_PHONE);
  $('copyPhone').textContent = 'Copied';
  setTimeout(() => { $('copyPhone').textContent = 'Copy number'; }, 1500);
});
$('closeTab').addEventListener('click', () => window.close());

updateHelp();
chrome.runtime.sendMessage({ type: 'lic-refresh', force: true }).then((r) => render(r && r.license)).catch(() => render(null));