/* Eegai Copy & Paste – isolated content script. */
(() => {
  'use strict';
  if (window.__eegaiCPIsolated) return;
  window.__eegaiCPIsolated = true;

  const IS_TOP = window === window.top;
  const SITE = siteKeyForTop();
  const STYLE_ID = 'eegai-cp-unlock-style';
  const TEXT_INPUTS = new Set(['text', 'search', 'email', 'url', 'tel', 'password', 'number', '']);
  let enabled = false;
  let lastEditable = null;

  // ---------- site key (always the top-level tab's site, even inside iframes) ----------
  function keyFromUrl(u) {
    try { const x = new URL(u); return x.hostname || 'local-files'; } catch (e) { return 'local-files'; }
  }
  function siteKeyForTop() {
    try {
      const a = location.ancestorOrigins;
      if (a && a.length) return keyFromUrl(a[a.length - 1]);
    } catch (e) {}
    try { return keyFromUrl(window.top.location.href); } catch (e) {}
    return keyFromUrl(location.href);
  }

  // ---------- state ----------
  function pushToPage() {
    document.dispatchEvent(new CustomEvent('eegai-cp-state', { detail: enabled }));
  }
  function applyStyle() {
    let el = document.getElementById(STYLE_ID);
    if (enabled && !el) {
      el = document.createElement('style');
      el.id = STYLE_ID;
      el.textContent =
        'html,body,body *{-webkit-user-select:text!important;user-select:text!important;-webkit-touch-callout:default!important}' +
        '::selection{background:#ffd27a!important;color:#1b2a4a!important}';
      const root = document.head || document.documentElement;
      if (root) root.appendChild(el);
      else document.addEventListener('DOMContentLoaded', applyStyle, { once: true });
    } else if (!enabled && el) {
      el.remove();
    }
  }
  function setEnabled(v) {
    enabled = !!v;
    pushToPage();
    applyStyle();
  }
  function loadState() {
    chrome.storage.local.get({ global: false, sites: {}, licensed: false }, (s) => {
      const site = s.sites[SITE];
      setEnabled(s.licensed && (typeof site === 'boolean' ? site : s.global));
    });
  }
  document.addEventListener('eegai-cp-hello', pushToPage, true);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.global || changes.sites || changes.licensed)) loadState();
  });
  loadState();
  // Some sites rebuild <head>; re-apply the style once the DOM is ready.
  document.addEventListener('DOMContentLoaded', applyStyle, { once: true });

  // ---------- track the last text box the user touched ----------
  function editableFrom(node) {
    let el = node && node.nodeType === 1 ? node : node && node.parentElement;
    while (el) {
      if (el.tagName === 'TEXTAREA') return el;
      if (el.tagName === 'INPUT' && TEXT_INPUTS.has((el.getAttribute('type') || '').toLowerCase())) return el;
      if (el.isContentEditable) {
        while (el.parentElement && el.parentElement.isContentEditable) el = el.parentElement;
        return el;
      }
      el = el.parentElement || (el.getRootNode && el.getRootNode().host) || null;
    }
    return null;
  }
  function deepActive() {
    let a = document.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    return a;
  }
  function remember(ev) {
    const target = ev.composedPath ? ev.composedPath()[0] : ev.target;
    const ed = editableFrom(target);
    if (ed && ed !== lastEditable) {
      lastEditable = ed;
      try { chrome.runtime.sendMessage({ type: 'eegai-focus' }); } catch (e) {}
    }
  }
  window.addEventListener('mousedown', remember, true);
  window.addEventListener('focusin', remember, true);

  // ---------- insert text like a real paste ----------
  function insertText(el, text) {
    if (!el || !el.isConnected) return false;
    if (el.readOnly || el.disabled) return false;
    el.focus();

    if (el.isContentEditable) {
      if (document.execCommand('insertText', false, text)) return true;
      const sel = window.getSelection();
      if (sel && sel.rangeCount) {
        const r = sel.getRangeAt(0);
        r.deleteContents();
        const node = document.createTextNode(text);
        r.insertNode(node);
        r.setStartAfter(node);
        r.collapse(true);
        sel.removeAllRanges();
        sel.addRange(r);
      } else {
        el.appendChild(document.createTextNode(text));
      }
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
      return true;
    }

    // <input> / <textarea>
    const before = el.value;
    let ok = false;
    try { ok = document.execCommand('insertText', false, text); } catch (e) {}
    if (ok && el.value !== before) return true;

    let start = null, end = null;
    try { start = el.selectionStart; end = el.selectionEnd; } catch (e) {}
    if (start == null) { start = before.length; end = before.length; }
    let next = before.slice(0, start) + text + before.slice(end);
    const max = el.maxLength;
    if (max > 0 && next.length > max) next = next.slice(0, max);

    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, next); // React/Angular friendly
    try { const p = Math.min(start + text.length, next.length); el.setSelectionRange(p, p); } catch (e) {}
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function currentSelection() {
    const a = deepActive();
    if (a && (a.tagName === 'TEXTAREA' || a.tagName === 'INPUT')) {
      try {
        const s = a.value.substring(a.selectionStart, a.selectionEnd);
        if (s) return s;
      } catch (e) {}
    }
    const sel = window.getSelection();
    return sel ? sel.toString() : '';
  }

  // ---------- toast (top frame only) ----------
  let toastHost = null, toastTimer = null;
  function toast(msg, kind) {
    if (!IS_TOP || !document.documentElement) return;
    if (!toastHost) {
      toastHost = document.createElement('div');
      toastHost.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:50%;bottom:28px;transform:translateX(-50%);pointer-events:none';
      const root = toastHost.attachShadow({ mode: 'closed' });
      root.innerHTML =
        '<style>.t{font:500 13px/1.3 "Segoe UI",system-ui,sans-serif;color:#fbfbf8;background:#1b2a4a;' +
        'padding:10px 16px;border-radius:999px;box-shadow:0 6px 20px rgba(27,42,74,.35);display:flex;gap:8px;align-items:center;' +
        'opacity:0;transform:translateY(8px);transition:opacity .18s,transform .18s}' +
        '.t.show{opacity:1;transform:none}.d{width:8px;height:8px;border-radius:50%;background:#f2a007}' +
        '.t.ok .d{background:#3ecf7a}.t.err .d{background:#ff6b5b}</style><div class="t"><span class="d"></span><span class="m"></span></div>';
      toastHost._t = root.querySelector('.t');
      toastHost._m = root.querySelector('.m');
    }
    if (!toastHost.isConnected) document.documentElement.appendChild(toastHost);
    toastHost._m.textContent = msg;
    toastHost._t.className = 't show ' + (kind || '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastHost._t.className = 't'; }, 1800);
  }

  // ---------- messages from background / popup ----------
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg && msg.type) {
      case 'eegai-insert': {
        let target = lastEditable && lastEditable.isConnected ? lastEditable : editableFrom(deepActive());
        sendResponse({ ok: insertText(target, msg.text) });
        break;
      }
      case 'eegai-get-selection':
        sendResponse({ text: currentSelection() });
        break;
      case 'eegai-page-text':
        sendResponse({ text: document.body ? document.body.innerText : '' });
        break;
      case 'eegai-toast':
        toast(msg.text, msg.kind);
        sendResponse({ ok: true });
        break;
      case 'eegai-ping':
        sendResponse({ site: SITE, enabled });
        break;
    }
  });
})();
