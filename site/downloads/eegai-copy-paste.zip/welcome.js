const $ = (id) => document.getElementById(id);
$('days').textContent = EEGAI_CONFIG.TRIAL_DAYS;
$('price').textContent = EEGAI_CONFIG.PRICE_INR;

function show(l) {
  const st = eegaiState(l);
  if (st === 'signed_out') { $('signedOut').hidden = false; $('signedIn').hidden = true; return; }
  if (st === 'expired' || st === 'pending') { location.href = 'subscribe.html'; return; }
  $('signedOut').hidden = true; $('signedIn').hidden = false;
  $('hello').textContent = st === 'premium' ? 'Premium is active' : "You're all set";
  if (st === 'trial') {
    const d = eegaiDaysLeft(l);
    $('stateText').textContent = 'Signed in as ' + l.email + '. Your free trial has ' + d + (d === 1 ? ' day' : ' days') + ' left.';
  } else if (st === 'premium') {
    $('stateText').textContent = 'Signed in as ' + l.email + '. Lifetime access on this computer.';
    $('upgrade').hidden = true;
  } else if (st === 'other_device') {
    $('stateText').textContent = 'Your licence is active on another computer. E-mail ' + (l.support || 'support') + ' to move it here.';
    $('upgrade').hidden = true;
  } else if (st === 'blocked') {
    $('stateText').textContent = 'Access for this account is disabled. Contact ' + (l.support || 'support') + '.';
    $('upgrade').hidden = true;
  }
}

$('signIn').addEventListener('click', async () => {
  $('signIn').disabled = true;
  $('msg').className = 'msg'; $('msg').textContent = 'Opening Google sign-in…';
  try {
    const deviceId = await eegaiDeviceId();
    const r = await chrome.runtime.sendMessage({ type: 'lic-signin', deviceId });
    if (!r.ok) throw new Error(r.error);
    $('msg').textContent = '';
    show(r.license);
  } catch (e) {
    $('msg').className = 'msg err'; $('msg').textContent = eegaiErrorText(e.message);
  } finally { $('signIn').disabled = false; }
});

chrome.runtime.sendMessage({ type: 'lic-refresh' }).then((r) => show(r && r.license)).catch(() => show(null));
