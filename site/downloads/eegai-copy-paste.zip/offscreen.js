chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'eegai-offscreen') return;
  const ta = document.getElementById('clip');
  try {
    if (msg.type === 'read') {
      ta.value = '';
      ta.focus();
      document.execCommand('paste');
      sendResponse({ text: ta.value });
    } else if (msg.type === 'write') {
      ta.value = msg.text || '';
      ta.select();
      const ok = document.execCommand('copy');
      sendResponse({ ok });
    }
  } catch (e) {
    sendResponse({ error: String(e) });
  }
});
