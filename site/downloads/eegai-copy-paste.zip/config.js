/* Eegai Copy & Paste – settings. Fill these in before loading / publishing. */
const EEGAI_CONFIG = {
  // Apps Script web-app URL (Deploy > Web app > copy URL ending in /exec)
  SERVER_URL: 'https://script.google.com/macros/s/AKfycbzY8_bfnh8lIYRhK1k5Zh_NGsVtVnAGvUdzq_mqEHTAzKCBY0jRo_GVqh8I6_XALvm3/exec',
  // Google Cloud OAuth client ID (type: Web application)
  GOOGLE_CLIENT_ID: '230606685546-p6fkvlfdi868nek9q2sld92e4qktpcuc.apps.googleusercontent.com',

  PRICE_INR: 50,
  TRIAL_DAYS: 7, // display only – the real value lives in the server (Code.gs)

  UPI_OPTIONS: [
    {
      label: 'UPI ID 1',
      upiId: '9500400427@superyes',
      payee: 'Sunthara Mahalingam Govindan',
      link: 'upi://pay?mode=01&ver=01&pa=9500400427%40superyes&pn=SUNTHARA+MAHALINGAM+GOVINDAN+&txntype=pay&qrmedium=02'
    },
    {
      label: 'UPI ID 2',
      upiId: 'gsmlingamagri92-4@okhdfcbank',
      payee: 'Gsm Lingam Agri',
      link: 'upi://pay?pa=gsmlingamagri92-4@okhdfcbank&pn=Gsm%20Lingam%20Agri&aid=uGICAgIDd-qXPTQ'
    }
  ]
};

/* UPI link with the amount and order reference pre-filled */
function eegaiUpiLink(opt, orderId) {
  return opt.link + '&am=' + EEGAI_CONFIG.PRICE_INR.toFixed(2) + '&cu=INR&tn=' +
    encodeURIComponent('Eegai CP ' + (orderId || ''));
}
